import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-critical-aspects',
  templateUrl: './critical-aspects.component.html',
  styleUrls: ['./critical-aspects.component.scss']
})
export class CriticalAspectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log('teste');
  }

}
