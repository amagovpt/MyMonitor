import { ToFixedPipe } from './to-fixed.pipe';

describe('ToFixedPipe', () => {
  it('create an instance', () => {
    const pipe = new ToFixedPipe();
    expect(pipe).toBeTruthy();
  });
});
