import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-pages-confirmation-dialog',
  templateUrl: './remove-pages-confirmation-dialog.component.html',
  styleUrls: ['./remove-pages-confirmation-dialog.component.scss']
})
export class RemovePagesConfirmationDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
