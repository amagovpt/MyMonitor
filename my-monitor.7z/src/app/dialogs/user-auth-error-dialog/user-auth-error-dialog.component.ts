import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-auth-error-dialog',
  templateUrl: './user-auth-error-dialog.component.html',
  styleUrls: ['./user-auth-error-dialog.component.scss']
})
export class UserAuthErrorDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
